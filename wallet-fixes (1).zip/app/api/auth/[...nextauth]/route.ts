import NextAuth from "next-auth"
import WorldcoinProvider from "next-auth/providers/worldcoin"

export const authOptions = {
  providers: [
    WorldcoinProvider({
      clientId: process.env.WLD_CLIENT_ID ?? "",
      clientSecret: process.env.WLD_CLIENT_SECRET ?? "",
    }),
  ],
  pages: {
    signIn: "/auth/signin",
    error: "/auth/error",
  },
  callbacks: {
    async session({ session, token }) {
      return session
    },
    async jwt({ token, user }) {
      if (user) {
        token.id = user.id
      }
      return token
    },
  },
}

const handler = NextAuth(authOptions)
export { handler as GET, handler as POST }

